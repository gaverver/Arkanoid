package com.example.myapplication;

public class Velocity {
    private double dx;
    private double dy;

    /**
     * .
     * the function gets two doubles and creates a new object from type Velocity
     *
     * @param dx - the dx value of the Velocity
     * @param dy - the dy value of the Velocity
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * .
     * calculates the Velocity in the x-axis and y-axis and returns it
     *
     * @param angle - the angle of the speed
     * @param speed - the size of it
     * @return the Velocity depends on the size and angle
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double dx = speed * Math.sin(angle * Math.PI / 180);
        double dy = speed * -Math.cos(angle * Math.PI / 180);
        return new Velocity(dx, dy);
    }

    /**
     * .
     * return the value of dx of this Velocity
     *
     * @return the dx value of the Velocity
     */
    public double getDx() {
        return this.dx;
    }

    /**
     * .
     * return the value of dy of this Velocity
     *
     * @return the dy value of the Velocity
     */
    public double getDy() {
        return this.dy;
    }

    /**
     * Sets velocity to a given values of dx and dy.
     *
     * @param dx the dx we change the value to
     * @param dy the dy we change the value to
     */
    public void setVelocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
}