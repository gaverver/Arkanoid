package com.example.myapplication;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.content.Context;

import androidx.annotation.NonNull;

import com.example.myapplication.Geometry.Point;

public class Ball extends View {
    private Point center;
    private int r;
    private Velocity v = new Velocity(0, 0);
    private int startX;
    private int startY;
    Context context;
    Paint ballPaint = new Paint();
    public Ball(Context context, Point center, int r, Velocity v) {
        super(context);
        this.context = context;
        this.center = center;
        this.r = r;
        this.v = new Velocity(v.getDx(), v.getDy());
    }
    public int xPoint() {
        return (int) this.center.getX();
    }
    public int yPoint() {
        return (int) this.center.getY();
    }
    public int getSize() {
        return this.r;
    }
    public void incX(int x) {
        this.center.setX(x);
    }
    public void incY(int y) {
        this.center.setY(y);
    }
    public Velocity getVelocity() {
        return this.v;
    }
    public void setVelocity(double dx, double dy) {
        this.v.setVelocity(dx, dy);
    }
    @Override
    public void draw(@NonNull Canvas canvas) {
        super.draw(canvas);
        this.ballPaint.setColor(Color.WHITE);
        canvas.drawCircle((float)this.center.getX(), (float)this.center.getY(), this.r, this.ballPaint);
    }


}
